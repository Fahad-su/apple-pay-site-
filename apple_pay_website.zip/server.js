const express = require("express");
const app = express();
const stripe = require("stripe")("sk_test_XXXXXXXXXXXX"); // استبدل بمفتاحك السري من Stripe

app.use(express.static("."));
app.use(express.json());

app.post("/create-checkout-session", async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card", "apple_pay"],
    line_items: [
      {
        price_data: {
          currency: "usd",
          product_data: { name: "منتج مميز" },
          unit_amount: 999,
        },
        quantity: 1,
      },
    ],
    mode: "payment",
    success_url: "https://your-site.com/success",
    cancel_url: "https://your-site.com/cancel",
  });

  res.json({ id: session.id });
});

app.listen(3000, () => console.log("سيرفر يعمل على http://localhost:3000"));
